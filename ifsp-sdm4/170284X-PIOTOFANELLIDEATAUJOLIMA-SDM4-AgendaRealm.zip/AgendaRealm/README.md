# Agenda
Projeto desenvolvido para a disciplina Banco de Dados para Computação Móvel (BDM) do curso de Pós-Graduação Lato Sensu em Desenvolvimento de Sistemas para Dispositivos Móveis do IFSP São Carlos.

Para ver a documentação, acesse: https://pdalbem.github.io/Agenda/

![ScreenShot](https://raw.github.com/pdalbem/Agenda/master/screenshots/screenshot1.jpg)

![ScreenShot](https://raw.github.com/pdalbem/Agenda/master/screenshots/screenshot2.jpg)

![ScreenShot](https://raw.github.com/pdalbem/Agenda/master/screenshots/screenshot3.jpg)

![ScreenShot](https://raw.github.com/pdalbem/Agenda/master/screenshots/screenshot4.jpg)

![ScreenShot](https://raw.github.com/pdalbem/Agenda/master/screenshots/screenshot5.jpg)

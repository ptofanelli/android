package br.edu.ifspsaocarlos.agenda.data;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import br.edu.ifspsaocarlos.agenda.model.Contato;
import io.realm.Realm;
import io.realm.RealmResults;

import java.util.ArrayList;
import java.util.List;


public class ContatoDAO {
    private SQLiteDatabase database;
    private SQLiteHelper dbHelper;

    private Realm realm;

    public ContatoDAO(Context context) {
        realm = Realm.getDefaultInstance();
    }

    public  List<Contato> buscaTodosContatos()
    {
        RealmResults<Contato> result = realm.where(Contato.class).findAll();
        return result;
    }

    public  List<Contato> buscaContato(String nome)
    {
        //realm = Realm.getDefaultInstance();

        RealmResults<Contato> result = realm.where(Contato.class).contains("nome",nome).findAll();

        //realm.close();

        return result;
    }

    public void salvaContato(Contato c) {
        //realm = Realm.getDefaultInstance();

        realm.beginTransaction();

        if(c.getId() > 0)
        {
            Contato contato = realm.where(Contato.class).equalTo("id",c.getId()).findFirst();
            contato.setEmail(c.getEmail());
            contato.setFone(c.getFone());
            contato.setNome(c.getNome());
        }
        else //novo contato
        {
            Integer maxid = 0;
            try {
                maxid = realm.where(Contato.class).findAll().max("id").intValue();
            } catch (Exception e) {}
            c.setId(maxid+1);
            realm.copyToRealm(c);
        }



        realm.commitTransaction();

        //realm.close();
    }



    public void apagaContato(Contato c)
    {
        //realm = Realm.getDefaultInstance();

        realm.beginTransaction();

        Contato contato = realm.where(Contato.class).equalTo("id",c.getId()).findFirst();
        contato.deleteFromRealm();

        realm.commitTransaction();

        //realm.close();
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        realm.close();
    }

    public Contato buscaContato(int id) {
        Contato c = realm.where(Contato.class).equalTo("id",id).findFirst();
        return realm.copyFromRealm(c);
    }
}

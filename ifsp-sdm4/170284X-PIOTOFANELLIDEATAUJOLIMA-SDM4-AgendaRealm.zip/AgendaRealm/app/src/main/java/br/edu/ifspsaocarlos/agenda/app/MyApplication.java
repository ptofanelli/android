package br.edu.ifspsaocarlos.agenda.app;

import android.app.Application;

import io.realm.Realm;

/**
 * Created by Pio Tofanelli on 08-Dec-17.
 */

public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Realm.init(this);
    }
}
